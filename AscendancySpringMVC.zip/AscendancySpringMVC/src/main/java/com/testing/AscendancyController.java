package com.testing;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;


import org.springframework.ui.ModelMap;

@Controller
@RequestMapping("/hello")
public class AscendancyController {
	
	@Autowired
    private LoginDAO loginDAO;
	
   @RequestMapping(value="/welcome",method = RequestMethod.GET)public String printHello(ModelMap model) {
      model.addAttribute("message", "Hello AscendancyController Spring MVC Framework!");
      return "hello";
   }
   
   @RequestMapping(value="/helloWelcome",method = RequestMethod.GET)
	public @ResponseBody String helloWorld() {
		
		String message = "Success";
		return  message;
	}
   
   @RequestMapping(value="/helloWelcome/{userid}/{password}",method = RequestMethod.GET)
	public @ResponseBody String helloWorld(@PathVariable("userid") String userid,@PathVariable("password") String password) {
		
		String message = "Logged User : "+userid;
		return  message;
	}
   
   @RequestMapping(value="/loginAuth",method = RequestMethod.POST)public ModelAndView loginAuth(@ModelAttribute("loginAuth") LoginUser loginuser) {
	   ModelAndView model = new ModelAndView("login");

	   String userPass=loginDAO.findEmployeeName(loginuser.getPassword());
	   if(loginuser.getPassword().equalsIgnoreCase(userPass)) {
		   model.addObject("message", "Ascendancy Login Successfull! "+loginuser.getUserid()+" : "+userPass);
		   model.setViewName("home");
		   return model;
	   }
		   model.addObject("message", "Ascendancy Login Failed! Please try Again !!"+loginuser.getUserid());
		   model.setViewName("login");
	      return model;
	   }
   @RequestMapping(value="/login",method = RequestMethod.GET)public String login(ModelMap model) {
	      model.addAttribute("message", "Ascendancy Login!");
	      return "login";
	   }
   
   @RequestMapping(value="/restPost",method = RequestMethod.POST)
	public @ResponseBody String restPost(LoginUser loginuser) {
		
		String message = "Rest Logged User : "+loginuser.getUserid();
		return  message;
	}
   
   
   @RequestMapping(value="/upadteAuth",method = RequestMethod.POST)public ModelAndView upadteAuth(@ModelAttribute("loginAuth") LoginUser loginuser) {
	   ModelAndView model = new ModelAndView("login");

	   int userPass=loginDAO.updateEmployeeName(loginuser.getUserid(),loginuser.getPassword());
	   if(userPass==1) {
		   model.addObject("message", "Ascendancy Update Successfull! "+loginuser.getUserid()+" : "+userPass);
		   model.setViewName("home");
		   return model;
	   }
		   model.addObject("message", "Ascendancy update Failed! Please try Again !!"+loginuser.getUserid());
		   model.setViewName("login");
	      return model;
	   }
}