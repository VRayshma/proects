package com.testing;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSetRow;

@Repository
public class LoginDAO {
	

	private JdbcTemplate jdbcTemplate;
    
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
    {
        this.jdbcTemplate = jdbcTemplate;
    }
    
    
	public String findEmployeeName(String empId) {
		
		String query = "select dept from employee where name='"+empId+"'"; 
		String pass=null;
		
		try {
			pass = jdbcTemplate.queryForObject(query, String.class);
		} 
		catch (EmptyResultDataAccessException e) {
		   return null;
		}
		return  pass;
	}
	
	public int updateEmployeeName(String empId,String password) {
		
		String query = "update employee set dept='"+password+"' where name='"+empId+"'"; 
		int pass=0;
		
		try {
			pass = jdbcTemplate.update(query);
		} 
		catch (EmptyResultDataAccessException e) {
		   return 0;
		}
		return  pass;
	}

}
